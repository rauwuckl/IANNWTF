import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import struct
import dataHandle
import scipy.ndimage


'''
dataHandle.preprocessImages(r"/mnt/c/Users/mpariani/Documents/UnivOsnabrueck/Third_Semester/ANNs_TensorFlow/trainData.pickle",
r"/mnt/c/Users/mpariani/Documents/UnivOsnabrueck/Third_Semester/ANNs_TensorFlow/trainDataHistEqual.pickle",
dataHandle.histogramEqualization)
'''


dataHandle.preprocessImages(r"/Users/dev/Downloads/Jannis/trainData.pickle",
r"/Users/dev/Downloads/Jannis/trainDataHistEqual.pickle",
dataHandle.histogramEqualization)
