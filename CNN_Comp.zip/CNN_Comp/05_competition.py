import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import struct
import dataHandle
import preprocessing

preprocessing

def fun_weight(shape):
    initvar = tf.truncated_normal(shape, stddev = 0.1)
    return tf.Variable(initvar)

def fun_bias(shape):
    initvar = tf.constant(0.1, shape = shape)
    return tf.Variable(initvar)

def fun_conv(x, W):
    return tf.nn.conv2d(x, W, strides = [1,1,1,1], padding = "SAME")
    
def fun_pool(x):
    return tf.nn.max_pool(x, ksize = [1,2,2,1], strides = [1,2,2,1], padding = "SAME")


my_activation_function = tf.nn.relu

learningRate = 1e-3
gdsOptimizer = tf.train.AdamOptimizer(learningRate)

# images
x = tf.placeholder(tf.float32, [None, 28, 28, 1])

# Here we input the correct answers
desired = tf.placeholder(tf.int64, [None])



conv_1 = fun_conv(x, fun_weight([3,3,1,32]))
act_1 = my_activation_function(conv_1 + fun_bias([32]))
    
conv_2 = fun_conv(act_1, fun_weight([3,3,32,32]))
act_2 = my_activation_function(conv_2 + fun_bias([32]))
pool_1 = fun_pool(act_2)

conv_3 = fun_conv(pool_1, fun_weight([3,3,32,64]))
act_3 = my_activation_function(conv_3 + fun_bias([64]))

conv_4 = fun_conv(act_3, fun_weight([3,3,64,64]))
act_4 = my_activation_function(conv_4 + fun_bias([64]))
pool_2 = fun_pool(act_4)

# 64 is the number of feature maps with size 7x7
# We project the output (7*7*64) on 1024 neurons
# Each neuron is connected and receives the whole weighted output of the previous layer.
w_ron_1 = fun_weight([7*7*64, 1024])
b_ron_1 = fun_bias([1024])

# Reshape for matrix mult --> why -1?
pool_2_flat = tf.reshape(pool_2, [-1, 7*7*64])
# Apply activation function
output_ron_1 = my_activation_function(tf.matmul(pool_2_flat, w_ron_1) + b_ron_1)

# Dropout
# keep_prob: probability that a neuron's output is kept during dropout
keep_prob = tf.placeholder(tf.float32)
output_ron_1_drop = tf.nn.dropout(output_ron_1, keep_prob)

# Do the same for last layer
w_ron_2 = fun_weight([1024,10])
b_ron_2 = fun_bias([10])

# Changed: input 'output_ron_1_drop'
output_ron_2 = tf.matmul(output_ron_1_drop, w_ron_2) + b_ron_2

crossEntropy = tf.nn.sparse_softmax_cross_entropy_with_logits(output_ron_2, desired)
crossEntropy = tf.reduce_mean(crossEntropy)

trainingStep = gdsOptimizer.minimize(crossEntropy)


prediction = tf.argmax(output_ron_2, 1)
nCorrect = tf.equal(prediction, desired)
#accuracy = tf.equal(tf.argmax(output_ron_2,1), tf.argmax(desired,1))
accuracy = tf.reduce_mean(tf.cast(nCorrect, tf.float32))

miniBatchSize = 300
plotStepSize = 25


#accuracyFigure, accuracyAxis = plt.subplots(1,1)
#weightFigure, weightAxes = plt.subplots(2,5)

# data = dataHandle.DataHandle()
data = dataHandle.DataHandle("./")

#savePath = "./run1.cpkt"
savePath = './run_epoch_'
restorePath = "./weights.cpkt"
#restorePath = None

trainingAccuracy = []
validationAccuracy = []
netPredictions = []
def trainNetwork(trainingSteps):
    with tf.Session() as session:
        saver = tf.train.Saver()
        if(restorePath is None):
            session.run(tf.initialize_all_variables())
            print("initialized variables")
        else:
            saver.restore(session, restorePath)
            print("restored variables")
        
        '''for step in range(trainingSteps):
                                    images, labels = data.getTrainingBatch(miniBatchSize)
                                    #print(labels)
                                    acc, netPrediction, _ = session.run([accuracy, prediction, trainingStep], feed_dict= {x: images, desired: labels, keep_prob: 0.5})
                        
                                    trainingAccuracy.append(acc)
                                    if step % 10 ==  0:
                                        print("{} accuracy at step {}".format(acc, step))
                                    if step % 100 == 0:
                                        print("{} accuracy at step {}".format(acc, step))
                                        _accuracy = [session.run(accuracy, feed_dict = {x: images, desired: labels, keep_prob: 1.0}) for images, labels in data.getValidationIterator(300)]
                                        print("Validation accuracy: ", np.mean(_accuracy))
                                    #if step % plotStepSize == 0 or step == trainingSteps - 1:
                                        #images, labels = mnist.getValidationData()
                                        #images = images.reshape([-1, 784])
                                        
                                        #_accuracy, _weights = session.run([accuracy, weights], feed_dict= {x: images, desired: labels})
                                        #if step != trainingSteps - 1:
                                        #    validationAccuracy[step:step+plotStepSize] = [_accuracy] * plotStepSize
                                        #accuracyAxis.cla()
                                        #accuracyAxis.plot(trainingAccuracy, color = 'b')
                                        #accuracyAxis.plot(validationAccuracy, color = 'r')
                                        #accuracyFigure.canvas.draw()
                        
                                        #for i in range(10):
                                        #    weight = _weights[:,i].reshape(28, 28)
                                        #    weightAxes[i // 5, i % 5].cla()
                                        #    weightAxes[i // 5, i % 5].matshow(weight, cmap = plt.get_cmap('bwr'))
                                        #weightFigure.canvas.draw()
                        
                                    if step % 1000 == 0 and (not savePath is None):
                                        s = savePath+str(step)+'.cpkt'
                                        path= saver.save(session, s)
                                        print("path: {}".format(path))
                        '''
        #plt.ion()
        #plt.figure()
        #plt.scatter(range(trainingSteps), netPrediction, c='r', label='Networks Estimate')
        #plt.scatter(range(trainingSteps), netPrediction, c='r', label='Networks Estimate')

        _accuracy = [session.run(accuracy, feed_dict = {x: images, desired: labels, keep_prob: 1.0}) for images, labels in data.getAllData(300)]
        print("accuracys: {}".format(_accuracy))
        # generator version is A LOT faster then putting evertything into one tensor (or I am not geting all)
        _accuracy = np.mean(_accuracy)
        print("Test accuracy: ", _accuracy)
trainNetwork(1)
